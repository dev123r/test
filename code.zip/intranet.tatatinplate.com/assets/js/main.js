	$('.dashboard_slider').flexslider({
		animation: "fade",
		animationSpeed: 2000,
		slideshowSpeed: 3000,
		controlNav: true,
		pauseOnHover: true,
		directionNav: false
		
	});
	$('.birthday_slider').flexslider({
		animation: "slide",
		animationSpeed: 800,
		slideshowSpeed: 7500,
		pauseOnHover: true,
		controlNav: false,
		directionNav: false
	});
	$('.photoslider').flexslider({
		animation:"fade",
		animationSpeed: 2000,
		slideshowSpeed: 3000,
		controlNav: false,
		directionNav: false
	});
	
	$(document).ready(function() {
		$('#telephone_directory').DataTable({
			 pageLengt: 3,
			 paging: false
		});
	startTime();
	} );
	(function($) {
    $.fn.newsticker = function(opts) {
        // default configuration
        var config = $.extend({}, {
            height: 30,
            speed: 800,
            start: 8,
            interval: 4000
        }, opts);
        // main function
        function init(obj) {
            var dNewsticker = obj,
                dFrame = dNewsticker.find('.newsticker-list'),
                dItem = dFrame.find('.newsticker-item'),
                dNext,
                stop = false;

            dItem.eq(0).addClass('current');

            setInterval(function() {
                if (!stop) {
                    var dCurrent = dFrame.find('.current');

                    dFrame.animate({
                        top: '-=' + config.height + 'px'
                    }, config.speed, function() {
                        dNext = dFrame.find('.current').next();
                        dNext.addClass('current');
                        dCurrent.removeClass('current');
                        dCurrent.clone().appendTo(dFrame);
                        dCurrent.remove();
                        dFrame.css('top', config.start + 'px');
                    });
                }
            }, config.interval);

            dNewsticker.on('mouseover mouseout', function(e) {
                if (e.type == 'mouseover') {
                    stop = true;
                } else { // mouseout
                    stop = false;
                }
            });
        }
        // initialize every element
        this.each(function() {
            init($(this));
        });
        return this;
    };
    // start
    $(function() {
        $('.newsticker').newsticker();
    });
})(jQuery);
 function startTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        m = checkTime(m);
        s = checkTime(s);
        var a='';
        if(h>12)
        {
            a='PM';
            h=h-12;
            var ht= h;
        }
        else {
            var ht= h;
            a='AM';
        }

        document.getElementById('clock').innerHTML =
            h + ":" + m + ":" + s+' '+a;
        var t = setTimeout(startTime, 500);
    }
     function checkTime(i) {
        if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
        return i;
    }
    
    
    
    
    
    
    
    $('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});